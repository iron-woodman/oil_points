﻿namespace oil_points.MyControls
{
    partial class ProtocolKMXTableControl
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.сохранитьВWordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lbValuesMeasurements = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbProtocolNumber = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbProtocolName = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lbBBIK = new System.Windows.Forms.Label();
            this.lbBLine3 = new System.Windows.Forms.Label();
            this.lbBLine2 = new System.Windows.Forms.Label();
            this.lbABIK = new System.Windows.Forms.Label();
            this.lbALine2 = new System.Windows.Forms.Label();
            this.lbALine3 = new System.Windows.Forms.Label();
            this.lbALine1 = new System.Windows.Forms.Label();
            this.lbBLine1 = new System.Windows.Forms.Label();
            this.lbCheckTime = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.DarkGray;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.ContextMenuStrip = this.contextMenuStrip1;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.DarkGray;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.DarkGray;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.GridColor = System.Drawing.Color.Black;
            this.dataGridView1.Location = new System.Drawing.Point(53, 143);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.RowHeadersVisible = false;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.ShowCellErrors = false;
            this.dataGridView1.Size = new System.Drawing.Size(600, 194);
            this.dataGridView1.TabIndex = 3;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.сохранитьВWordToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(183, 26);
            // 
            // сохранитьВWordToolStripMenuItem
            // 
            this.сохранитьВWordToolStripMenuItem.Name = "сохранитьВWordToolStripMenuItem";
            this.сохранитьВWordToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.сохранитьВWordToolStripMenuItem.Text = "Сохранить в Word...";
            this.сохранитьВWordToolStripMenuItem.Click += new System.EventHandler(this.сохранитьВWordToolStripMenuItem_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.DarkGray;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.lbValuesMeasurements, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbCheckTime, 1, 6);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 8;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(676, 439);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // lbValuesMeasurements
            // 
            this.lbValuesMeasurements.AutoSize = true;
            this.lbValuesMeasurements.Dock = System.Windows.Forms.DockStyle.Right;
            this.lbValuesMeasurements.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbValuesMeasurements.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lbValuesMeasurements.Location = new System.Drawing.Point(578, 110);
            this.lbValuesMeasurements.Name = "lbValuesMeasurements";
            this.lbValuesMeasurements.Size = new System.Drawing.Size(75, 30);
            this.lbValuesMeasurements.TabIndex = 1;
            this.lbValuesMeasurements.Text = "Значния ";
            this.lbValuesMeasurements.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbProtocolNumber);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(53, 33);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(600, 44);
            this.panel1.TabIndex = 1;
            // 
            // lbProtocolNumber
            // 
            this.lbProtocolNumber.AutoSize = true;
            this.lbProtocolNumber.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbProtocolNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbProtocolNumber.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lbProtocolNumber.Location = new System.Drawing.Point(0, 0);
            this.lbProtocolNumber.Name = "lbProtocolNumber";
            this.lbProtocolNumber.Size = new System.Drawing.Size(135, 25);
            this.lbProtocolNumber.TabIndex = 1;
            this.lbProtocolNumber.Text = "Протокол №";
            this.lbProtocolNumber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbProtocolName);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(53, 83);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(600, 24);
            this.panel2.TabIndex = 1;
            // 
            // lbProtocolName
            // 
            this.lbProtocolName.AutoSize = true;
            this.lbProtocolName.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbProtocolName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbProtocolName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lbProtocolName.Location = new System.Drawing.Point(0, 0);
            this.lbProtocolName.Name = "lbProtocolName";
            this.lbProtocolName.Size = new System.Drawing.Size(223, 16);
            this.lbProtocolName.TabIndex = 1;
            this.lbProtocolName.Text = "КМХ плотномеров по ареометру ";
            this.lbProtocolName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.Controls.Add(this.lbBBIK, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.lbBLine3, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.lbBLine2, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.lbABIK, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.lbALine2, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.lbALine3, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.lbALine1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.lbBLine1, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(53, 343);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(600, 94);
            this.tableLayoutPanel2.TabIndex = 4;
            // 
            // lbBBIK
            // 
            this.lbBBIK.AutoSize = true;
            this.lbBBIK.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbBBIK.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lbBBIK.Location = new System.Drawing.Point(453, 47);
            this.lbBBIK.Name = "lbBBIK";
            this.lbBBIK.Size = new System.Drawing.Size(127, 30);
            this.lbBBIK.TabIndex = 6;
            this.lbBBIK.Text = "Датчик А линия 1 годен";
            // 
            // lbBLine3
            // 
            this.lbBLine3.AutoSize = true;
            this.lbBLine3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbBLine3.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lbBLine3.Location = new System.Drawing.Point(303, 47);
            this.lbBLine3.Name = "lbBLine3";
            this.lbBLine3.Size = new System.Drawing.Size(127, 30);
            this.lbBLine3.TabIndex = 5;
            this.lbBLine3.Text = "Датчик А линия 1 годен";
            // 
            // lbBLine2
            // 
            this.lbBLine2.AutoSize = true;
            this.lbBLine2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbBLine2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lbBLine2.Location = new System.Drawing.Point(153, 47);
            this.lbBLine2.Name = "lbBLine2";
            this.lbBLine2.Size = new System.Drawing.Size(127, 30);
            this.lbBLine2.TabIndex = 4;
            this.lbBLine2.Text = "Датчик А линия 1 годен";
            // 
            // lbABIK
            // 
            this.lbABIK.AutoSize = true;
            this.lbABIK.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbABIK.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lbABIK.Location = new System.Drawing.Point(453, 0);
            this.lbABIK.Name = "lbABIK";
            this.lbABIK.Size = new System.Drawing.Size(127, 30);
            this.lbABIK.TabIndex = 3;
            this.lbABIK.Text = "Датчик А линия 1 годен";
            // 
            // lbALine2
            // 
            this.lbALine2.AutoSize = true;
            this.lbALine2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbALine2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lbALine2.Location = new System.Drawing.Point(153, 0);
            this.lbALine2.Name = "lbALine2";
            this.lbALine2.Size = new System.Drawing.Size(127, 30);
            this.lbALine2.TabIndex = 1;
            this.lbALine2.Text = "Датчик А линия 1 годен";
            // 
            // lbALine3
            // 
            this.lbALine3.AutoSize = true;
            this.lbALine3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbALine3.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lbALine3.Location = new System.Drawing.Point(303, 0);
            this.lbALine3.Name = "lbALine3";
            this.lbALine3.Size = new System.Drawing.Size(127, 30);
            this.lbALine3.TabIndex = 2;
            this.lbALine3.Text = "Датчик А линия 1 годен";
            // 
            // lbALine1
            // 
            this.lbALine1.AutoSize = true;
            this.lbALine1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbALine1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lbALine1.Location = new System.Drawing.Point(3, 0);
            this.lbALine1.Name = "lbALine1";
            this.lbALine1.Size = new System.Drawing.Size(127, 30);
            this.lbALine1.TabIndex = 0;
            this.lbALine1.Text = "Датчик А линия 1 годен";
            // 
            // lbBLine1
            // 
            this.lbBLine1.AutoSize = true;
            this.lbBLine1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbBLine1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lbBLine1.Location = new System.Drawing.Point(3, 47);
            this.lbBLine1.Name = "lbBLine1";
            this.lbBLine1.Size = new System.Drawing.Size(127, 30);
            this.lbBLine1.TabIndex = 0;
            this.lbBLine1.Text = "Датчик А линия 1 годен";
            // 
            // lbCheckTime
            // 
            this.lbCheckTime.AutoSize = true;
            this.lbCheckTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbCheckTime.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lbCheckTime.Location = new System.Drawing.Point(53, 440);
            this.lbCheckTime.Name = "lbCheckTime";
            this.lbCheckTime.Size = new System.Drawing.Size(167, 15);
            this.lbCheckTime.TabIndex = 0;
            this.lbCheckTime.Text = "Дата проведения КМХ: ";
            // 
            // ProtocolKMXTableControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "ProtocolKMXTableControl";
            this.Size = new System.Drawing.Size(676, 439);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem сохранитьВWordToolStripMenuItem;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbProtocolNumber;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbProtocolName;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label lbBBIK;
        private System.Windows.Forms.Label lbBLine3;
        private System.Windows.Forms.Label lbBLine2;
        private System.Windows.Forms.Label lbABIK;
        private System.Windows.Forms.Label lbALine2;
        private System.Windows.Forms.Label lbALine3;
        private System.Windows.Forms.Label lbALine1;
        private System.Windows.Forms.Label lbBLine1;
        private System.Windows.Forms.Label lbCheckTime;
        private System.Windows.Forms.Label lbValuesMeasurements;
    }
}
